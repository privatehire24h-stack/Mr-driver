import React from 'react';
import { Plane, MapPin, Clock, Compass, Car, ArrowRight, ShieldCheck, Phone, MessageSquare } from 'lucide-react';
import { ServiceType } from '../types/booking';
import userLogoImg from '../assets/images/mr_driver_user_logo.jpg';

interface CompactHubProps {
  onSelectService: (service: ServiceType) => void;
  onOpenFleet: () => void;
  onOpenDayTrips: () => void;
  onOpenContact: () => void;
}

export const CompactHub: React.FC<CompactHubProps> = ({
  onSelectService,
  onOpenFleet,
  onOpenDayTrips,
  onOpenContact,
}) => {
  return (
    <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 pt-4 pb-6">
      {/* Friendly Welcome & Brand Card */}
      <div className="bg-gradient-to-r from-[#0a1222] via-[#0d182b] to-[#0a1222] border border-amber-500/25 rounded-2xl p-5 sm:p-7 shadow-2xl relative overflow-hidden mb-6">
        {/* Subtle background glow */}
        <div className="absolute -top-16 -right-16 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 sm:gap-6 text-center sm:text-left relative z-10">
          {/* Logo Badge */}
          <div className="w-18 h-18 sm:w-20 sm:h-20 shrink-0 rounded-2xl p-1 bg-gradient-to-tr from-amber-500 via-amber-300 to-amber-600 shadow-xl shadow-black/80">
            <img
              src={userLogoImg}
              alt="MR DRIVER Mercedes-Benz Barcelona"
              className="w-full h-full object-cover rounded-[13px]"
            />
          </div>

          <div className="flex-1 space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase text-amber-300 bg-amber-950/70 border border-amber-500/30">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Official Mercedes-Benz Chauffeur • Terminal 1 El Prat Barcelona</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold text-white font-cinzel tracking-tight">
              Where would you like to travel today?
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Select an option below to begin your reservation. Guaranteed fixed rates, flight delay tracking, and executive Mercedes-Benz hospitality.
            </p>
          </div>

          {/* Quick Direct WhatsApp Button */}
          <div className="sm:self-center shrink-0">
            <a
              href="https://wa.me/34664032244"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/40 transition-all hover:scale-105 active:scale-95"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp Concierge</span>
            </a>
          </div>
        </div>
      </div>

      {/* Friendly Service Options Grid: Tap any option to open the next step */}
      <div className="mb-2">
        <div className="text-xs font-bold text-amber-400 uppercase tracking-widest mb-3 flex items-center justify-between">
          <span>Choose an option to open next step:</span>
          <span className="text-[11px] text-slate-400 font-normal normal-case">Instant Step-by-Step Flow</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Option 1: Airport Pick-Up */}
          <button
            type="button"
            onClick={() => onSelectService('airport')}
            className="group text-left p-4 rounded-xl bg-gradient-to-b from-[#0b1424] to-[#080e1a] border border-amber-500/20 hover:border-amber-400 hover:from-[#0e1a30] hover:to-[#0a1222] transition-all duration-200 shadow-lg hover:shadow-amber-500/10 cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Plane className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-500/30">
                  From €75
                </span>
              </div>
              <h3 className="font-bold text-white text-sm group-hover:text-amber-300 transition-colors">
                Airport Pick-Up
              </h3>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                BCN Terminal 1 &amp; 2 • Live flight tracking &amp; tablet nameboard
              </p>
            </div>
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-semibold">
              <span>Next: Enter Terminal</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Option 2: City & Cruise Port */}
          <button
            type="button"
            onClick={() => onSelectService('point_to_point')}
            className="group text-left p-4 rounded-xl bg-gradient-to-b from-[#0b1424] to-[#080e1a] border border-amber-500/20 hover:border-amber-400 hover:from-[#0e1a30] hover:to-[#0a1222] transition-all duration-200 shadow-lg hover:shadow-amber-500/10 cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <MapPin className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-500/30">
                  Fixed Rates
                </span>
              </div>
              <h3 className="font-bold text-white text-sm group-hover:text-amber-300 transition-colors">
                City &amp; Cruise Port
              </h3>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Hotels, Passeig de Gràcia, Port Moll Adossat Cruise Terminals
              </p>
            </div>
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-semibold">
              <span>Next: Set Route</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Option 3: Hourly Chauffeur */}
          <button
            type="button"
            onClick={() => onSelectService('hourly')}
            className="group text-left p-4 rounded-xl bg-gradient-to-b from-[#0b1424] to-[#080e1a] border border-amber-500/20 hover:border-amber-400 hover:from-[#0e1a30] hover:to-[#0a1222] transition-all duration-200 shadow-lg hover:shadow-amber-500/10 cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Clock className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-500/30">
                  4h – 12h
                </span>
              </div>
              <h3 className="font-bold text-white text-sm group-hover:text-amber-300 transition-colors">
                Hourly Disposal
              </h3>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Dedicated suited chauffeur on standby for business or shopping
              </p>
            </div>
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-semibold">
              <span>Next: Select Hours</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Option 4: Catalonia Day Trips */}
          <button
            type="button"
            onClick={() => onSelectService('day_trip')}
            className="group text-left p-4 rounded-xl bg-gradient-to-b from-[#0b1424] to-[#080e1a] border border-amber-500/20 hover:border-amber-400 hover:from-[#0e1a30] hover:to-[#0a1222] transition-all duration-200 shadow-lg hover:shadow-amber-500/10 cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Compass className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded-md border border-amber-500/30">
                  Scenic Tours
                </span>
              </div>
              <h3 className="font-bold text-white text-sm group-hover:text-amber-300 transition-colors">
                Catalonia Day Trips
              </h3>
              <p className="text-[11px] text-slate-400 mt-1 leading-snug">
                Montserrat Mountain, Andorra Pyrenees, Girona &amp; Costa Brava
              </p>
            </div>
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs text-amber-400 font-semibold">
              <span>Next: Pick Destination</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

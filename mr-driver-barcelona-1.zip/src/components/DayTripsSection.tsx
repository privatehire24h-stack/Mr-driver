import React from 'react';
import { Compass, Clock, MapPin, ArrowRight, Check } from 'lucide-react';
import { DAY_TRIPS } from '../data/dayTrips';
import { Currency } from '../types/booking';

interface DayTripsSectionProps {
  currency: Currency;
  onSelectDayTrip: (tripId: string) => void;
}

const CURRENCY_RATES = {
  EUR: { symbol: '€', rate: 1.0 },
  USD: { symbol: '$', rate: 1.09 },
  GBP: { symbol: '£', rate: 0.85 },
};

export const DayTripsSection: React.FC<DayTripsSectionProps> = ({ currency, onSelectDayTrip }) => {
  const cur = CURRENCY_RATES[currency];

  return (
    <section id="day-trips" className="py-20 bg-[#070d18] border-t border-slate-800/80 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="text-xs uppercase font-bold tracking-[0.25em] text-amber-400 mb-2">
            Curated Catalonia Excursions
          </div>
          <h2 className="text-2xl sm:text-4xl font-bold text-white font-cinzel mb-3">
            Private VIP Day Trips &amp; Tours
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Discover the majesty of Catalonia with an executive Mercedes-Benz chauffeur at your exclusive service. Custom itineraries, flexible timing, and absolute privacy.
          </p>
        </div>

        {/* Day Trips Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {DAY_TRIPS.map((trip) => {
            const convertedPrice = Math.round(trip.priceEUR * cur.rate);

            return (
              <div
                key={trip.id}
                className="rounded-2xl bg-[#091122] border border-slate-800 hover:border-amber-500/40 transition-all flex flex-col justify-between overflow-hidden shadow-xl"
              >
                <div>
                  <div className="h-60 w-full overflow-hidden relative bg-slate-950">
                    <img
                      src={trip.image}
                      alt={trip.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#091122] via-transparent to-transparent" />
                    
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs">
                      <span className="bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-md text-amber-400 font-semibold border border-amber-500/30 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{trip.duration}</span>
                      </span>
                      <span className="bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-md text-slate-300 border border-slate-700 flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-amber-400" />
                        <span>{trip.distance}</span>
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2">{trip.title}</h3>
                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                      {trip.description}
                    </p>

                    <div className="space-y-2 mb-6">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Tour Highlights
                      </div>
                      {trip.highlights.map((item, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                          <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0 flex items-center justify-between border-t border-slate-800/80 pt-4">
                  <div>
                    <div className="text-[10px] text-slate-400 uppercase">Total Private Tour Fare</div>
                    <div className="text-xl font-bold text-white font-mono tabular-nums">
                      {cur.symbol}{convertedPrice}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onSelectDayTrip(trip.id);
                      const el = document.getElementById('booking-engine');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs sm:text-sm rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span>Reserve Tour</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

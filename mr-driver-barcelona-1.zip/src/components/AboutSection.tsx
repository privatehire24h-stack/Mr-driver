import React from 'react';
import { ShieldCheck, Award, Clock, Star, MapPin, CheckCircle2, UserCheck, Sparkles } from 'lucide-react';
import userLogoImg from '../assets/images/mr_driver_user_logo.jpg';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-[#050a14] border-t border-slate-800/80 relative overflow-hidden scroll-mt-24">
      {/* Background Ambience */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold tracking-widest uppercase text-amber-400 bg-amber-950/50 border border-amber-500/30 mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The Gold Standard of Private Chauffeurs</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white font-cinzel mb-4">
            About MR DRIVER Barcelona
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Headquartered at Terminal 1, El Prat de Llobregat Barcelona, MR DRIVER is Catalonia’s premier executive private hire and luxury chauffeur company. We blend punctuality, elite Mercedes-Benz hospitality, and zero-compromise discretion.
          </p>
        </div>

        {/* 2-Column Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          
          {/* Left Column: Visual Brand Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl p-1 bg-gradient-to-tr from-amber-500/30 via-slate-800 to-amber-500/10 shadow-2xl">
              <div className="rounded-[22px] bg-[#091122] p-8 border border-slate-800/80 space-y-6">
                
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl p-0.5 bg-gradient-to-tr from-amber-500 to-amber-300 shadow-md">
                    <img
                      src={userLogoImg}
                      alt="MR DRIVER Mercedes Emblem"
                      className="w-full h-full object-cover rounded-2xl"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white font-cinzel">MR DRIVER</h3>
                    <p className="text-xs text-amber-400 font-medium">Barcelona Executive Chauffeur</p>
                    <p className="text-[11px] text-slate-400">Licencia VTC / Generalitat de Catalunya</p>
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-800 text-xs text-slate-300">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block">Strategic Airport Base:</strong>
                      <span>Terminal 1, El Prat de Llobregat, Barcelona — Chauffeurs stationed within minutes of arrival terminals.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block">24/7 Flight Telemetry:</strong>
                      <span>Automated flight tracking with 60 minutes free delay buffer; your chauffeur is always ready when you land.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white block">Certified VIP Chauffeurs:</strong>
                      <span>Suit-and-tie dress code, multilingual, vetted, and trained in defensive and executive client etiquette.</span>
                    </div>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-950/80 rounded-xl border border-amber-500/20 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Dispatch Helpline:</span>
                  <a
                    href="https://wa.me/34664032244"
                    target="_blank"
                    rel="noreferrer"
                    className="text-amber-400 font-bold hover:underline"
                  >
                    +34 664 03 22 44
                  </a>
                </div>

              </div>
            </div>
          </div>

          {/* Right Column: Key Commitments */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-white font-cinzel mb-3">
                Why Discerning Guests Choose MR DRIVER
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed">
                Whether you are traveling for the Mobile World Congress (MWC), boarding a luxury cruise at Port de Barcelona, or exploring the peaks of Montserrat and the Pyrenees of Andorra, we treat every mile as a bespoke first-class experience.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-[#0a1222] border border-slate-800 hover:border-amber-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-3">
                  <Award className="w-5 h-5" />
                </div>
                <h4 className="text-white font-bold text-sm mb-1.5">Official VTC Licensure</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  100% compliant with Spanish transport regulations. All vehicles carry complete commercial passenger liability coverage.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#0a1222] border border-slate-800 hover:border-amber-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-3">
                  <UserCheck className="w-5 h-5" />
                </div>
                <h4 className="text-white font-bold text-sm mb-1.5">Meet &amp; Greet Excellence</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Chauffeurs wait at the arrival hall holding personalized digital iPads, assist with luggage, and escort you directly to the car.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#0a1222] border border-slate-800 hover:border-amber-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-3">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <h4 className="text-white font-bold text-sm mb-1.5">Guaranteed Fixed Rates</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  No surge pricing, no hidden luggage fees, and no surprise toll charges. What you quote is exactly what you pay.
                </p>
              </div>

              <div className="p-5 rounded-2xl bg-[#0a1222] border border-slate-800 hover:border-amber-500/40 transition-colors">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-3">
                  <Star className="w-5 h-5" />
                </div>
                <h4 className="text-white font-bold text-sm mb-1.5">First-Class Fleet Standards</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Mercedes-Benz E-Class, S-Class, V-Class (7 Pax), and zero-emission Tesla sedans detailed and sanitized before every reservation.
                </p>
              </div>
            </div>

          </div>

        </div>

        {/* Real Metrics Counter Strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 p-6 rounded-2xl bg-[#091122] border border-slate-800">
          <div className="text-center p-3">
            <div className="text-3xl sm:text-4xl font-extrabold text-amber-400 font-cinzel">15,000+</div>
            <div className="text-xs text-slate-400 mt-1 uppercase tracking-wider">Completed Transfers</div>
          </div>
          <div className="text-center p-3">
            <div className="text-3xl sm:text-4xl font-extrabold text-white font-cinzel">99.8%</div>
            <div className="text-xs text-slate-400 mt-1 uppercase tracking-wider">On-Time Punctuality</div>
          </div>
          <div className="text-center p-3">
            <div className="text-3xl sm:text-4xl font-extrabold text-amber-400 font-cinzel">4.99 ★</div>
            <div className="text-xs text-slate-400 mt-1 uppercase tracking-wider">Client Satisfaction</div>
          </div>
          <div className="text-center p-3">
            <div className="text-3xl sm:text-4xl font-extrabold text-white font-cinzel">24 / 7</div>
            <div className="text-xs text-slate-400 mt-1 uppercase tracking-wider">Live Chauffeur Dispatch</div>
          </div>
        </div>

      </div>
    </section>
  );
};

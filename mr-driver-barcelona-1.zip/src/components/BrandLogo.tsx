import React from 'react';
import userLogoImg from '../assets/images/mr_driver_user_logo.jpg';

interface BrandLogoProps {
  variant?: 'full' | 'compact' | 'badge-only' | 'seal-large';
  className?: string;
  showTagline?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'full',
  className = '',
  showTagline = false,
}) => {
  const logoSrc = userLogoImg || '/logo.png';

  // Large Seal variant (for hero displays or presentation)
  if (variant === 'seal-large') {
    return (
      <div className={`relative flex flex-col items-center justify-center ${className}`}>
        <div className="relative group">
          <div className="absolute -inset-1.5 bg-gradient-to-r from-amber-500 via-amber-300 to-amber-600 rounded-3xl blur-md opacity-50 group-hover:opacity-75 transition duration-500"></div>
          <div className="relative w-44 h-44 sm:w-56 sm:h-56 rounded-3xl p-1 bg-gradient-to-tr from-amber-500 via-amber-300 to-amber-600 shadow-2xl shadow-black/80">
            <img
              src={logoSrc}
              alt="MR DRIVER Mercedes-Benz Luxury Chauffeur Barcelona"
              className="w-full h-full object-cover rounded-[22px]"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
        <div className="mt-3 text-center">
          <span className="inline-block px-3 py-1 text-[11px] font-semibold tracking-widest uppercase text-amber-300 bg-amber-950/60 border border-amber-500/40 rounded-full">
            Mercedes-Benz Luxury Fleet
          </span>
        </div>
      </div>
    );
  }

  // Badge only (compact squircle icon)
  if (variant === 'badge-only') {
    return (
      <div className={`relative shrink-0 ${className}`}>
        <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl p-0.5 bg-gradient-to-tr from-amber-500 via-amber-300 to-amber-600 shadow-md shadow-black/60">
          <img
            src={logoSrc}
            alt="MR DRIVER Mercedes-Benz Seal"
            className="w-full h-full object-cover rounded-[10px]"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>
    );
  }

  // Compact variant
  if (variant === 'compact') {
    return (
      <div className={`flex items-center gap-2 select-none ${className}`}>
        <div className="relative shrink-0 w-10 h-10 rounded-xl p-0.5 bg-gradient-to-tr from-amber-500 via-amber-300 to-amber-600 shadow-md">
          <img
            src={logoSrc}
            alt="MR DRIVER Mercedes Logo"
            className="w-full h-full object-cover rounded-[9px]"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="flex flex-col leading-tight">
          <span className="text-base font-black tracking-tight text-white font-cinzel">
            MR <span className="text-amber-400">DRIVER</span>
          </span>
          <span className="text-[9px] uppercase tracking-widest text-slate-400">
            Mercedes Fleet BCN
          </span>
        </div>
      </div>
    );
  }

  // Default: Full Brand Logo with the Official Mercedes & MR DRIVER Emblem + Typography
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Official Squircle Chauffeur Badge with Mercedes-Benz */}
      <div className="relative shrink-0 flex items-center justify-center w-11 h-11 md:w-13 md:h-13 rounded-xl p-0.5 bg-gradient-to-tr from-amber-500 via-amber-300 to-amber-600 shadow-lg shadow-black/70 hover:scale-105 transition-transform duration-300">
        <img
          src={logoSrc}
          alt="MR DRIVER Barcelona Mercedes-Benz Seal"
          className="w-full h-full object-cover rounded-[10px]"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Typography */}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5 leading-none">
          <span className="text-xl md:text-2xl font-black tracking-tight text-white font-cinzel">
            MR
          </span>
          <span className="text-xl md:text-2xl font-black tracking-wider text-amber-400 font-cinzel flex items-center">
            DR
            {/* The signature location pin letter 'O' with yellow dot */}
            <span className="relative inline-flex items-center justify-center mx-0.5">
              <svg className="w-5 h-5 text-amber-400" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
              </svg>
            </span>
            VER
          </span>
        </div>

        {/* Mercedes-Benz & Barcelona Subtitle */}
        <div className="flex items-center gap-1.5 mt-1">
          <span className="text-[10px] uppercase font-bold tracking-[0.22em] text-amber-400">
            Mercedes-Benz
          </span>
          <span className="text-amber-500/60">•</span>
          <span className="text-[10px] uppercase font-bold tracking-[0.25em] text-slate-300">
            Barcelona
          </span>
        </div>

        {showTagline && (
          <span className="text-[11px] text-slate-300 italic font-serif mt-1">
            Your Journey, Our Priority • 24/7 Private Hire
          </span>
        )}
      </div>
    </div>
  );
};

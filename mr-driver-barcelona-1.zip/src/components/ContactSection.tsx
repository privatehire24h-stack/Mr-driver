import React, { useState } from 'react';
import { Phone, Mail, MapPin, MessageSquare, Send, CheckCircle2, Clock, ShieldCheck, ArrowRight } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('Airport Pick-Up (BCN Terminal 1 / 2)');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide your name');
      return;
    }
    if (!phone.trim() && !email.trim()) {
      setError('Please provide either a phone number or an email');
      return;
    }

    setError('');
    setSubmitted(true);
  };

  const handleSendToWhatsApp = () => {
    const text = `*MR DRIVER Barcelona - Website Inquiry*\n\n` +
      `Name: ${name || 'Guest'}\n` +
      `Contact Phone: ${phone || 'Not specified'}\n` +
      `Email: ${email || 'Not specified'}\n` +
      `Service: ${service}\n` +
      (message ? `Details: ${message}\n\n` : '\n') +
      `Base: Terminal 1 El Prat de Llobregat Barcelona`;

    const url = `https://wa.me/34664032244?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  return (
    <section id="contact" className="py-24 bg-[#060b16] border-t border-slate-800 relative scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold tracking-widest uppercase text-amber-400 bg-amber-950/50 border border-amber-500/30 mb-3">
            <Clock className="w-3.5 h-3.5" />
            <span>24/7 Dedicated Concierge &amp; Dispatch</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white font-cinzel mb-4">
            Contact MR DRIVER
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Need an urgent airport pickup, multi-day executive chauffeur, or custom itinerary? Contact our 24/7 dispatch desk directly.
          </p>
        </div>

        {/* 2-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: Direct Contact Details & Cards */}
          <div className="lg:col-span-5 space-y-4">
            
            {/* WhatsApp Priority Card */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-[#0a1420] to-[#070d18] border border-emerald-500/40 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded-full border border-emerald-500/30">
                  Instant Reply
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white">Direct WhatsApp Concierge</h3>
                <p className="text-xs text-slate-300 mt-1">
                  Connect with our duty manager in seconds for real-time rates, custom routes, and immediate flight pickups.
                </p>
              </div>

              <a
                href="https://wa.me/34664032244?text=Hello%20MR%20DRIVER%20Barcelona%2C%20I%20would%20like%20to%20inquire%20about%20a%20luxury%20chauffeur%20transfer."
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-950 transition-all cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp (+34 664 032 244)</span>
              </a>
            </div>

            {/* Direct Phone Card */}
            <div className="p-5 rounded-2xl bg-[#0a1222] border border-slate-800 hover:border-amber-500/40 transition-colors flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-slate-400">24/7 Phone Line</div>
                  <a
                    href="tel:+34664032244"
                    className="text-white font-bold text-sm hover:text-amber-400 transition-colors font-mono"
                  >
                    +34 664 03 22 44
                  </a>
                </div>
              </div>
              <a
                href="tel:+34664032244"
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700"
              >
                Call Now
              </a>
            </div>

            {/* Email Card */}
            <div className="p-5 rounded-2xl bg-[#0a1222] border border-slate-800 hover:border-amber-500/40 transition-colors flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] uppercase tracking-wider text-slate-400">Official Reservations</div>
                  <a
                    href="mailto:privatehire24h@gmail.com"
                    className="text-white font-bold text-sm hover:text-amber-400 transition-colors"
                  >
                    privatehire24h@gmail.com
                  </a>
                </div>
              </div>
              <a
                href="mailto:privatehire24h@gmail.com"
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700"
              >
                Send Email
              </a>
            </div>

            {/* Address Card */}
            <div className="p-5 rounded-2xl bg-[#0a1222] border border-slate-800 flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[11px] uppercase tracking-wider text-slate-400">Headquarters &amp; Dispatch Base</div>
                <div className="text-white font-semibold text-sm">Terminal 1 elprat de Llobregat Barcelona</div>
                <p className="text-xs text-slate-400 mt-1">
                  Josep Tarradellas Barcelona-El Prat Airport (BCN) · Catalonia, Spain
                </p>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive VIP Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-3xl bg-[#091122] border border-slate-800 shadow-2xl">
              <div className="mb-6">
                <h3 className="text-xl font-bold text-white font-cinzel">Direct VIP Inquiry Form</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Fill in your travel details for instant quotation or bespoke group itinerary.
                </p>
              </div>

              {submitted ? (
                <div className="p-6 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white">Inquiry Received</h4>
                    <p className="text-xs text-slate-300 mt-1 max-w-md mx-auto">
                      Thank you, {name}. Our 24/7 concierge desk has logged your request and will reach out via WhatsApp / Email shortly.
                    </p>
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={handleSendToWhatsApp}
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Forward to WhatsApp for Immediate Reply</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSubmitted(false)}
                      className="px-4 py-2.5 text-xs text-slate-400 hover:text-white cursor-pointer"
                    >
                      Submit Another Inquiry
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {error && (
                    <div className="p-3 bg-red-950/50 border border-red-500/50 rounded-xl text-xs text-red-300">
                      {error}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Elena Rostova"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                        WhatsApp / Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+34 664 03 22 44"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="privatehire24h@gmail.com"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                        Service Required
                      </label>
                      <select
                        value={service}
                        onChange={(e) => setService(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                      >
                        <option value="Airport Pick-Up (BCN Terminal 1 / 2)">Airport Pick-Up (BCN Terminal 1 / 2)</option>
                        <option value="Port de Barcelona Cruise Transfer">Port de Barcelona Cruise Transfer</option>
                        <option value="Andorra Pyrenees Day Excursion">Andorra Pyrenees Day Excursion</option>
                        <option value="Empuriabrava Canal Tour">Empuriabrava Canal Tour</option>
                        <option value="Lloret de Mar / Costa Brava">Lloret de Mar / Costa Brava</option>
                        <option value="Salou / PortAventura Transfer">Salou / PortAventura Transfer</option>
                        <option value="As-Directed Hourly Executive Chauffeur">As-Directed Hourly Executive Chauffeur</option>
                        <option value="Corporate / MWC Delegation Transport">Corporate / MWC Delegation Transport</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
                      Message / Flight Details / Special Itinerary
                    </label>
                    <textarea
                      rows={3}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Share your flight number, luggage count, date, destination, or any bespoke requirements..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                    <button
                      type="submit"
                      className="w-full sm:flex-1 py-3 px-6 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-sm rounded-xl shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span>Submit Inquiry</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleSendToWhatsApp}
                      className="w-full sm:w-auto py-3 px-4 bg-emerald-600/90 hover:bg-emerald-500 text-white font-medium text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Send via WhatsApp</span>
                    </button>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};

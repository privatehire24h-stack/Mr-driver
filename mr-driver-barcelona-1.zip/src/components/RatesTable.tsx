import React from 'react';
import { Currency } from '../types/booking';
import { ShieldCheck, Zap } from 'lucide-react';

interface RatesTableProps {
  currency: Currency;
  onBookRoute: (pickup: string, dropoff: string) => void;
}

const RATES_DATA = [
  {
    from: 'BCN Airport Terminal 1 & 2',
    to: 'Barcelona City Center (Passeig de Gràcia / Eixample)',
    distance: '16 km',
    duration: '25 min',
    teslaModel3EUR: 75,
    eClassEUR: 85,
    sClassMaybachEUR: 130,
    vClassVanEUR: 110,
  },
  {
    from: 'BCN Airport Terminal 1 & 2',
    to: 'W Barcelona & Waterfront 5★ Hotels',
    distance: '18 km',
    duration: '20 min',
    teslaModel3EUR: 75,
    eClassEUR: 85,
    sClassMaybachEUR: 130,
    vClassVanEUR: 110,
  },
  {
    from: 'BCN Airport Terminal 1 & 2',
    to: 'Port de Barcelona Cruise Terminals (A, B, C, D, E)',
    distance: '15 km',
    duration: '18 min',
    teslaModel3EUR: 75,
    eClassEUR: 85,
    sClassMaybachEUR: 130,
    vClassVanEUR: 110,
  },
  {
    from: 'Barcelona City Center',
    to: 'Sitges Coastal Village & Beach',
    distance: '42 km',
    duration: '40 min',
    teslaModel3EUR: 120,
    eClassEUR: 135,
    sClassMaybachEUR: 195,
    vClassVanEUR: 165,
  },
  {
    from: 'Barcelona City Center',
    to: 'Montserrat Mountain Sanctuary',
    distance: '55 km',
    duration: '55 min',
    teslaModel3EUR: 145,
    eClassEUR: 160,
    sClassMaybachEUR: 230,
    vClassVanEUR: 195,
  },
  {
    from: 'Barcelona City Center',
    to: 'Girona Historic Quarter',
    distance: '102 km',
    duration: '1h 15m',
    teslaModel3EUR: 215,
    eClassEUR: 240,
    sClassMaybachEUR: 340,
    vClassVanEUR: 290,
  },
  {
    from: 'Barcelona City Center',
    to: 'Andorra la Vella / Pyrenees (Tax-Free & Caldea)',
    distance: '200 km',
    duration: '2h 45m',
    teslaModel3EUR: 290,
    eClassEUR: 330,
    sClassMaybachEUR: 470,
    vClassVanEUR: 395,
  },
  {
    from: 'Barcelona City Center',
    to: 'Empuriabrava Marina (Venice of Spain - Costa Brava)',
    distance: '152 km',
    duration: '1h 45m',
    teslaModel3EUR: 230,
    eClassEUR: 260,
    sClassMaybachEUR: 370,
    vClassVanEUR: 315,
  },
  {
    from: 'Barcelona City Center',
    to: 'Lloret de Mar (Santa Clotilde & Costa Brava Beaches)',
    distance: '76 km',
    duration: '1h 00m',
    teslaModel3EUR: 135,
    eClassEUR: 150,
    sClassMaybachEUR: 215,
    vClassVanEUR: 180,
  },
  {
    from: 'Barcelona City Center',
    to: 'Salou & PortAventura World (Costa Daurada)',
    distance: '110 km',
    duration: '1h 15m',
    teslaModel3EUR: 175,
    eClassEUR: 195,
    sClassMaybachEUR: 275,
    vClassVanEUR: 235,
  },
];

const CURRENCY_RATES = {
  EUR: { symbol: '€', rate: 1.0 },
  USD: { symbol: '$', rate: 1.09 },
  GBP: { symbol: '£', rate: 0.85 },
};

export const RatesTable: React.FC<RatesTableProps> = ({ currency, onBookRoute }) => {
  const cur = CURRENCY_RATES[currency];

  const format = (eur: number) => {
    return `${cur.symbol}${Math.round(eur * cur.rate)}`;
  };

  return (
    <section id="rates" className="py-20 bg-[#060c17] border-t border-slate-800/80 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <div className="text-xs uppercase font-bold tracking-[0.25em] text-amber-400 mb-2">
              Transparent &amp; Guaranteed
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold text-white font-cinzel mb-3">
              Fixed Rates Across Key Barcelona Routes
            </h2>
            <p className="text-sm sm:text-base text-slate-300">
              No taxi meters. No unexpected surge pricing during heavy rain or congress events. The price quoted is the price you pay.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Includes highway tolls, airport parking fees, and 60-min waiting buffer.</span>
          </div>
        </div>

        {/* Mobile Swipe Hint */}
        <div className="flex md:hidden items-center justify-between px-3 py-2 mb-3 text-xs text-amber-300 bg-amber-950/50 border border-amber-500/30 rounded-xl">
          <span>Scroll table horizontally to compare all vehicle classes</span>
          <span className="font-bold font-mono">→</span>
        </div>

        {/* Responsive Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-[#0a1222] shadow-2xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/80 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <th className="py-4 px-6">Route (Origin → Destination)</th>
                <th className="py-4 px-4 hidden sm:table-cell">Est. Transit</th>
                <th className="py-4 px-4 text-center">
                  <div className="text-emerald-400 font-bold flex items-center justify-center gap-1">
                    <Zap className="w-3.5 h-3.5" />
                    <span>Tesla Model 3</span>
                  </div>
                  <div className="text-[10px] text-slate-400 normal-case font-normal">100% Electric EV</div>
                </th>
                <th className="py-4 px-4 text-center">
                  <div className="text-white font-bold">Business Class</div>
                  <div className="text-[10px] text-slate-400 normal-case font-normal">Mercedes E-Class</div>
                </th>
                <th className="py-4 px-4 text-center">
                  <div className="text-amber-400 font-bold">First Class VIP</div>
                  <div className="text-[10px] text-slate-400 normal-case font-normal">Mercedes S-Class / Maybach</div>
                </th>
                <th className="py-4 px-4 text-center">
                  <div className="text-white font-bold">VIP Minivan</div>
                  <div className="text-[10px] text-slate-400 normal-case font-normal">Mercedes V-Class (7 Pax)</div>
                </th>
                <th className="py-4 px-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-sm">
              {RATES_DATA.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-4 px-6">
                    <div className="font-semibold text-white">{row.from}</div>
                    <div className="text-xs text-slate-400">→ {row.to}</div>
                  </td>
                  <td className="py-4 px-4 hidden sm:table-cell text-xs text-slate-400">
                    <div>{row.duration}</div>
                    <div className="text-[11px] text-slate-500 font-mono tabular-nums">{row.distance}</div>
                  </td>
                  <td className="py-4 px-4 text-center font-mono font-semibold text-emerald-400 tabular-nums">
                    {format(row.teslaModel3EUR)}
                  </td>
                  <td className="py-4 px-4 text-center font-mono font-semibold text-slate-200 tabular-nums">
                    {format(row.eClassEUR)}
                  </td>
                  <td className="py-4 px-4 text-center font-mono font-bold text-amber-400 tabular-nums">
                    {format(row.sClassMaybachEUR)}
                  </td>
                  <td className="py-4 px-4 text-center font-mono font-semibold text-slate-200 tabular-nums">
                    {format(row.vClassVanEUR)}
                  </td>
                  <td className="py-4 px-6 text-right">
                    <button
                      type="button"
                      onClick={() => onBookRoute(row.from, row.to)}
                      className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      Book Ride
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>
    </section>
  );
};

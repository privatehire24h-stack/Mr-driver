import React from 'react';
import { ShieldCheck, Clock, UserCheck, Sparkles, Navigation, Award } from 'lucide-react';

export const VipBenefits: React.FC = () => {
  const benefits = [
    {
      icon: Clock,
      title: 'Punctuality & Free 60-Min Delay Buffer',
      description: 'We connect directly to Barcelona El Prat (BCN) air radar. Even if your flight is delayed by hours, your chauffeur will adjust pickup time with zero penalty or waiting surcharges.'
    },
    {
      icon: UserCheck,
      title: 'Certified Multilingual Chauffeurs',
      description: 'Polite, impeccably groomed, background-checked chauffeurs fluent in English and Spanish (Urdu/Hindi or Arabic speakers available upon request for visiting VIP families).'
    },
    {
      icon: Sparkles,
      title: 'Obsidian Black Mercedes-Benz Standard',
      description: 'Only current-generation Mercedes-Maybach, S-Class, and V-Class Extra Long. Sanitized before every single trip with complimentary chilled water, Wi-Fi, and chargers.'
    },
    {
      icon: Award,
      title: 'Transparent Fixed All-Inclusive Pricing',
      description: 'All highway AP-7 and C-32 tolls, Barcelona city taxes, airport access permits, and driver gratuity are fully included in the price quoted at booking.'
    },
    {
      icon: ShieldCheck,
      title: 'VIP Discretion & Privacy Protocol',
      description: 'Strict privacy guarantees for executives, high-net-worth families, diplomats, and celebrities. Acoustic privacy glass and silent transit available upon request.'
    },
    {
      icon: Navigation,
      title: 'Bespoke Catalonia Tour Flexibility',
      description: 'Need to pause at Montserrat for photos or extend your dinner at Costa Brava? Your chauffeur adapts effortlessly to your personal schedule.'
    }
  ];

  return (
    <section className="py-20 bg-[#070d18] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="max-w-3xl mb-14">
          <div className="text-xs uppercase font-bold tracking-[0.25em] text-amber-400 mb-2">
            The MR DRIVER Standard
          </div>
          <h2 className="text-2xl sm:text-4xl font-bold text-white font-cinzel mb-3">
            Why Discerning Guests Choose Us
          </h2>
          <p className="text-sm sm:text-base text-slate-300">
            A luxury transfer is more than just a car ride—it is the first and lasting impression of your stay in Barcelona.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-[#091122] border border-slate-800/80 hover:border-amber-500/30 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-4">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

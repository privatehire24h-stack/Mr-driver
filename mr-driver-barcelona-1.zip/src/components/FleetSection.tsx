import React from 'react';
import { Users, Briefcase, Wifi, Shield, ArrowRight, Check } from 'lucide-react';
import { FLEET_DATA } from '../data/fleet';
import { Currency } from '../types/booking';

interface FleetSectionProps {
  currency: Currency;
  onSelectVehicle: (vehicleId: string) => void;
}

const CURRENCY_RATES = {
  EUR: { symbol: '€', rate: 1.0 },
  USD: { symbol: '$', rate: 1.09 },
  GBP: { symbol: '£', rate: 0.85 },
};

export const FleetSection: React.FC<FleetSectionProps> = ({ currency, onSelectVehicle }) => {
  const cur = CURRENCY_RATES[currency];

  return (
    <section id="fleet" className="py-20 bg-[#060c17] border-t border-slate-800/80 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
          <div className="max-w-2xl">
            <div className="text-xs uppercase font-bold tracking-[0.25em] text-amber-400 mb-2">
              Executive &amp; VIP Electric Fleet
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold text-white font-cinzel mb-3">
              Crafted for Discerning Travelers
            </h2>
            <p className="text-sm sm:text-base text-slate-300">
              From flagship Mercedes-Maybach and S-Class limousines to zero-emission Tesla Model 3 electric executive sedans and spacious V-Class VIP passenger vans.
            </p>
          </div>

          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>All vehicles insured with VIP passenger public liability coverage</span>
          </div>
        </div>

        {/* Fleet Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FLEET_DATA.map((vehicle) => {
            const convertedBase = Math.round(vehicle.basePriceEUR * cur.rate);
            const convertedHourly = Math.round(vehicle.hourlyRateEUR * cur.rate);

            return (
              <div
                key={vehicle.id}
                className="rounded-2xl bg-[#0a1222] border border-slate-800 hover:border-amber-500/40 transition-all flex flex-col justify-between overflow-hidden group shadow-xl"
              >
                <div>
                  {/* Vehicle Image Container */}
                  <div className="h-56 w-full overflow-hidden relative bg-slate-950">
                    <img
                      src={vehicle.image}
                      alt={vehicle.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0a1222] via-transparent to-transparent opacity-80" />
                    
                    <div className="absolute top-4 left-4">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-md border border-amber-500/30">
                        {vehicle.category}
                      </span>
                    </div>
                  </div>

                  {/* Details Body */}
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-1">{vehicle.name}</h3>
                    <div className="text-xs text-slate-400 mb-4">{vehicle.model}</div>

                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                      {vehicle.description}
                    </p>

                    {/* Capacity Specs */}
                    <div className="grid grid-cols-2 gap-3 py-3 border-y border-slate-800 text-xs text-slate-300 mb-6">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-amber-400" />
                        <span>Up to {vehicle.passengers} Passengers</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Briefcase className="w-4 h-4 text-amber-400" />
                        <span>{vehicle.luggage} Large Luggage</span>
                      </div>
                    </div>

                    {/* Key Amenities */}
                    <div className="space-y-2 mb-6">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Chauffeur Amenities
                      </div>
                      {vehicle.features.map((feat, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                          <Check className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Pricing & Booking Footer */}
                <div className="p-6 pt-0">
                  <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800/80 mb-4 flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                        From Airport / City
                      </div>
                      <div className="text-lg font-bold text-white font-mono tabular-nums">
                        {cur.symbol}{convertedBase}
                        <span className="text-xs text-slate-400 font-sans font-normal"> / transfer</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">
                        Hourly Disposal
                      </div>
                      <div className="text-sm font-semibold text-amber-400 font-mono tabular-nums">
                        {cur.symbol}{convertedHourly}
                        <span className="text-xs text-slate-400 font-sans font-normal"> / hour</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onSelectVehicle(vehicle.id);
                      const el = document.getElementById('booking-engine');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="w-full py-3 px-4 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                  >
                    <span>Book {vehicle.name}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};

import { DayTrip } from '../types/booking';

export const DAY_TRIPS: DayTrip[] = [
  {
    id: 'barcelona-andorra-pyrenees',
    title: 'Barcelona to Andorra Pyrenees & Shopping VIP Tour',
    duration: '10 to 11 Hours',
    distance: '410 km Roundtrip',
    description: 'Cross into the majestic mountain Principality of Andorra nestled high in the Pyrenees. Experience duty-free luxury boutique shopping along Avinguda Meritxell, thermal wellness at Caldea Spa, and breathtaking alpine mountain vistas with zero cross-border driving hassle.',
    priceEUR: 580,
    image: '/src/assets/images/daytrip_andorra_pyrenees_1792111853757.jpg',
    highlights: [
      'Scenic Pyrenees mountain pass route via Cadí Tunnel & Moixeró',
      'Duty-free luxury designer shopping on Avinguda Meritxell',
      'Caldea Thermal Spa wellness or Grandvalira ski resort stop',
      'Smooth international border crossing with professional bilingual chauffeur',
      'Complimentary onboard cold beverages & Wi-Fi for alpine route'
    ]
  },
  {
    id: 'barcelona-empuriabrava-canal',
    title: 'Barcelona to Empuriabrava "Venice of Spain" & Dalí Coast',
    duration: '8 to 9 Hours',
    distance: '310 km Roundtrip',
    description: 'Explore Europe\'s premier residential marina with over 25 km of navigable canals and luxury waterfront villas in the Gulf of Roses. Rent a private electric canal boat, visit the famed Salvador Dalí Museum in nearby Figueres, and indulge in Mediterranean seafood by the marina.',
    priceEUR: 480,
    image: '/src/assets/images/daytrip_empuriabrava_canal_1792111854926.jpg',
    highlights: [
      'Private canal cruise through Empuriabrava\'s residential waterways',
      'Spectacular Mediterranean views across the Bay of Roses',
      'Optional VIP detour to Salvador Dalí Theatre-Museum in Figueres',
      'Waterfront gastronomy & fresh seafood reservations assistance',
      'Obsidian-black Mercedes sedan or minivan with dedicated waiting time'
    ]
  },
  {
    id: 'barcelona-lloret-de-mar',
    title: 'Barcelona to Lloret de Mar & Santa Clotilde Coastal Tour',
    duration: '6 to 7 Hours',
    distance: '155 km Roundtrip',
    description: 'Journey to the vibrant jewel of the southern Costa Brava. Stroll the historic clifftop Santa Clotilde Italianate Gardens with sweeping panoramic views over crystal turquoise coves, relax on pristine Mediterranean sands at Fenals Beach, or explore the promenade.',
    priceEUR: 340,
    image: '/src/assets/images/daytrip_lloret_de_mar_1792111901183.jpg',
    highlights: [
      'Clifftop walk through the 1919 Italian Renaissance Santa Clotilde Gardens',
      'Crystal-clear swimming & relaxation at secluded Cala Boadella cove',
      'Seaside seafood dining along the vibrant Lloret beachfront promenade',
      'Gran Casino Costa Brava & historic modernist architecture stops',
      'Direct executive transfer with scenic coastal drive return'
    ]
  },
  {
    id: 'barcelona-salou-costa-daurada',
    title: 'Barcelona to Salou Costa Daurada & PortAventura VIP Trip',
    duration: '7 to 8 Hours',
    distance: '225 km Roundtrip',
    description: 'Head south along the golden sands of the Costa Daurada. Perfect for an adrenaline-filled family excursion to PortAventura World and Ferrari Land, a stroll down Salou\'s palm-lined Passeig Jaume I, or a cultural visit to UNESCO Roman Tarragona nearby.',
    priceEUR: 360,
    image: '/src/assets/images/daytrip_salou_costa_daurada_1792111900716.jpg',
    highlights: [
      'VIP front-gate drop-off & flexible pickup at PortAventura & Ferrari Land',
      'Leisurely seaside stroll along palm-lined Passeig Jaume I & golden beaches',
      'Optional detour to the UNESCO Roman Amphitheatre & Aqueduct in Tarragona',
      'Spacious luggage and family gear capacity in luxury Mercedes V-Class or S-Class',
      'Coordinated return schedule tailored around evening park shows & fireworks'
    ]
  },
  {
    id: 'montserrat-royal-tour',
    title: 'Montserrat Royal Sanctuary & Black Madonna',
    duration: '5 to 6 Hours',
    distance: '110 km Roundtrip',
    description: 'Travel through the dramatic multi-peaked serrated mountain range to Catalonia\'s spiritual holy sanctuary, Santa Maria de Montserrat Abbey, and breathtaking panoramic viewpoints.',
    priceEUR: 320,
    image: '/src/assets/images/daytrip_montserrat_tour_1792076007909.jpg',
    highlights: [
      'Private scenic mountain ascent & descent',
      'Flexible time to visit Black Madonna & Basilica',
      'Optional Funicular Sant Joan assistance',
      'Dedicated Mercedes chauffeur on standby'
    ]
  },
  {
    id: 'girona-costa-brava',
    title: 'Girona Medieval Old Quarter & Costa Brava',
    duration: '8 to 9 Hours',
    distance: '230 km Roundtrip',
    description: 'Immerse yourself in Girona\'s Jewish Quarter and iconic Romanesque cathedral (famed in Game of Thrones), followed by cliffside coastal roads along Tossa de Mar in Costa Brava.',
    priceEUR: 490,
    image: '/src/assets/images/hero_chauffeur_barcelona_1792076007095.jpg',
    highlights: [
      'Walking pause in historic Jewish Call of Girona',
      'Panoramic coastal drive along Costa Brava cliffs',
      'Seafood lunch reservation coordination at Tossa de Mar',
      'Door-to-door luxury VIP sedan or van return'
    ]
  },
  {
    id: 'penedes-wine-cava',
    title: 'Penedès Private Wine & Cava Master Tasting',
    duration: '6 to 7 Hours',
    distance: '130 km Roundtrip',
    description: 'Tour world-renowned boutique family vineyards in the heart of Catalonia\'s premier wine region. Private cellars, cava tasting, and scenic rolling Mediterranean hills.',
    priceEUR: 390,
    image: '/src/assets/images/fleet_maybach_luxury_1792076007808.jpg',
    highlights: [
      'Visits to historic wineries (Cordoniu / Gramona / Torres)',
      'No stress of driving between wine estates',
      'Trunk capacity for wine crate purchases',
      'Relaxed gourmet lunch schedule'
    ]
  },
  {
    id: 'sitges-panoramic',
    title: 'Sitges Mediterranean Seaside & Garraf Coast',
    duration: '5 Hours',
    distance: '85 km Roundtrip',
    description: 'Cruise the picturesque Garraf coastal curves to the whitewashed bohemian seaside jewel of Sitges, famed for its palatial promenade, art museums, and Mediterranean beaches.',
    priceEUR: 280,
    image: '/src/assets/images/hero_chauffeur_barcelona_1792076007095.jpg',
    highlights: [
      'Breathtaking Garraf cliffside scenic drive',
      'Leisurely seaside stroll along Sant Bartomeu promenade',
      'Boutique shopping & waterfront terrace dining',
      'Flexible chauffeur waiting time'
    ]
  }
];
